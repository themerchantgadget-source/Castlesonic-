# SONARA — Offline Media Vault: Patch Upgrade Mission

The original, complete Sonara codebase has been received and audited. We are ready to execute the three exact surgical upgrades without rewriting or breaking any of the existing workspaces, Web Audio EQ, lyrics, photo lightbox, code editor sandbox, or IndexedDB persistence.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The complete codebase was received in the previous turn. We have audited all DOM elements, event listeners, and CSS rules.
> Review this updated plan and click **Proceed** to execute the patch upgrade directly into `index.html`.

- **Scope A (Icon-Only Controls)**: All text labels on actionable buttons will be removed in favor of Lucide icons, while adding/preserving `title` and `aria-label` attributes for WCAG accessibility and tooltips. Static section titles, data indicators, and EQ preset names will remain.
- **Scope B (Auto-Hide Video Controls)**: 2.5s inactivity timer on play/resume, tap-to-reveal without pause, smooth fade transitions with `.controls-hidden`, active scrubbing guard, and paused visibility.
- **Scope C (Media-Element Rotation Math)**: Direct transform on `#video-element` cycling 0° → 90° → 180° → 270° → 0° with `scale = Math.min(cw/ch, ch/cw)` so the rotated video stays fitted within `#video-container` without overflow, dynamically recalculated on resize and fullscreen changes.

---

## 1. Scope A: Alphabet Removal Audit & Mapping

Every actionable button will be converted to an icon-only control with a minimum 40px–44px hit target, retaining `title` and `aria-label`:

| Target Element | Current Markup / Label | Upgraded Icon-Only Replacement |
| :--- | :--- | :--- |
| `#btn-import-video` | `<button class="btn-accent">... Import</button>` | `<i data-lucide="plus"></i>` (`title="Import Video"`) |
| `#btn-import-photos` | `<button class="btn-accent">... Import Photos</button>` | `<i data-lucide="plus"></i>` (`title="Import Photos"`) |
| `#btn-import-docs` | `<button class="btn-accent">... Import</button>` | `<i data-lucide="plus"></i>` (`title="Import Documents"`) |
| `#btn-library-import` | `<button class="btn-accent">... Import</button>` | `<i data-lucide="plus"></i>` (`title="Import Media"`) |
| `#link-see-all` | `<span>See All</span>` | `<button class="header-icon-btn"><i data-lucide="chevron-right"></i></button>` |
| `#video-fullscreen-btn` | `<i data-lucide="maximize"></i> Full` | `<i data-lucide="maximize"></i>` (`title="Toggle Fullscreen"`) |
| `#video-landscape-btn` | `<i data-lucide="smartphone"></i> Wide` | `<i data-lucide="smartphone"></i>` (rotated 90deg, `title="Toggle Landscape"`) |
| `#video-rotate-btn` | `<i data-lucide="rotate-cw"></i> Rotate` | `<i data-lucide="rotate-cw"></i>` (`title="Rotate 90°"`) |
| `#video-boost-btn` | `100% Boost` | `<i data-lucide="volume-2"></i> <span class="badge">100%</span>` |
| `#video-fit-btn` | `FIT: Contain` | `<i data-lucide="scaling"></i>` (`title="Aspect Fit"`) |
| `#btn-toggle-editor-mode` | `Code` | `<i data-lucide="code"></i>` (`title="Code Editor"`) |
| `#btn-toggle-preview-mode` | `Live Preview` | `<i data-lucide="eye"></i>` (`title="Live Preview"`) |
| `#btn-doc-subtab-files` | `Files` | `<i data-lucide="folder"></i>` (`title="Files"`) |
| `#btn-doc-subtab-editor` | `Code & Notes` | `<i data-lucide="code"></i>` (`title="Code & Notes"`) |
| `#editor-theme-dark/sepia/light` | `Dark`, `Sepia`, `Light` | `<i data-lucide="moon"></i>`, `<i data-lucide="sun-dim"></i>`, `<i data-lucide="sun"></i>` |
| `#editor-font-dec / inc` | `A-`, `A+` | `<i data-lucide="minus"></i>`, `<i data-lucide="plus"></i>` |
| `#editor-btn-new-template` | `+ Template` | `<i data-lucide="file-plus"></i>` (`title="Load Template"`) |
| `#editor-preview-refresh` | `Refresh` | `<i data-lucide="refresh-cw"></i>` (`title="Refresh"`) |
| `#editor-preview-fullscreen` | `Theater Mode` | `<i data-lucide="maximize"></i>` (`title="Theater Mode"`) |
| `#editor-preview-exit-btn` | `Exit` | `<i data-lucide="x"></i>` (`title="Exit Theater"`) |
| `#modal-eq-reset` | `Reset to Flat` | `<i data-lucide="rotate-ccw"></i>` (`title="Reset to Flat"`) |
| `#modal-lyrics-save` | `Done` | `<i data-lucide="check"></i>` (`title="Done"`) |
| `#btn-cancel-delete` | `Cancel` | `<i data-lucide="x"></i>` (`title="Cancel"`) |
| `#btn-execute-delete` | `Delete` | `<i data-lucide="trash-2"></i>` (`title="Delete"`) |
| `#btn-export-backup` | `Export Catalog JSON` | `<i data-lucide="download"></i>` (`title="Export JSON"`) |
| `#btn-import-backup` | `Restore Backup` | `<i data-lucide="upload"></i>` (`title="Restore Backup"`) |
| `#btn-reset-preferences` | `Reset Preferences` | `<i data-lucide="rotate-ccw"></i>` (`title="Reset Preferences"`) |
| `#btn-clear-vault` | `Clear Entire Vault` | `<i data-lucide="trash-2"></i>` (`title="Clear Vault"`) |
| `#settings-eq-toggle-btn` | `Active` / `Bypassed` | `<i data-lucide="power"></i>` (`title="Toggle EQ"`) |
| `#btn-clear-queue` | `Clear Queue` | `<i data-lucide="trash-2"></i>` (`title="Clear Queue"`) |
| `#fallback-btn-retry-webm` | `Repackage as WebM Stream` | `<i data-lucide="refresh-cw"></i>` (`title="Repackage as WebM"`) |
| `#fallback-btn-export` | `Download Original Video` | `<i data-lucide="download"></i>` (`title="Download Video"`) |
| Filter Chips (`#library-filter-chips`) | `All Files 0`, `Music 0`, etc. | Icon + numeric badge only (`folder`, `music`, `film`, `image`, `file-text`, `code`) |
| Search Inputs | Text placeholders | Empty placeholder with leading `<i data-lucide="search"></i>` + `aria-label` |
| Dropzone (`#home-dropzone`) | Text explanation | `<i data-lucide="upload-cloud"></i>` icon only, with `aria-label` |
| `#btn-open-eq-modal`, `#btn-open-lyrics-modal` | `Equalizer`, `Lyrics / Notes` | `<i data-lucide="sliders"></i>`, `<i data-lucide="align-left"></i>` (centered, 44px hit) |

---

## 2. Scope B: Video Controls Auto-Hide Architecture

```
                               [Video Play Event]
                                       │
                                       ▼
                             ┌───────────────────┐
                             │ Start 2.5s Timer  │
                             └─────────┬─────────┘
                                       │
              ┌────────────────────────┴────────────────────────┐
              ▼ (2.5s timeout)                                  ▼ (User interaction)
   ┌───────────────────────┐                        ┌───────────────────────┐
   │ Add .controls-hidden  │                        │ Reset 2.5s Timer      │
   │ Opacity: 0            │                        │ Remove .controls-hidden
   │ Pointer-events: none  │                        └───────────────────────┘
   └──────────┬────────────┘
              │
              ▼ (Container Tap while hidden)
   ┌────────────────────────────────────────┐
   │ Reveal controls ONLY (e.preventDefault) │
   │ Do NOT pause video or toggle playback  │
   │ Restart 2.5s timer                     │
   └────────────────────────────────────────┘
```

### CSS Transition Rules
```css
.video-overlay-top,
.video-controls {
  transition: opacity 0.25s cubic-bezier(0.16, 1, 0.3, 1), transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}

.video-stage-container.controls-hidden .video-overlay-top {
  opacity: 0 !important;
  pointer-events: none !important;
  transform: translateY(-8px);
}

.video-stage-container.controls-hidden .video-controls {
  opacity: 0 !important;
  pointer-events: none !important;
  transform: translateY(8px);
}
```

---

## 3. Scope C: Video Media-Element Rotation Math

### Scaling Formula
When rotated to 90° or 270°, the video element dimensions swap relative to the container. To prevent clipping or overflow while preserving `object-fit`:
$$\text{scale} = \min\left(\frac{w_{\text{container}}}{h_{\text{container}}}, \frac{h_{\text{container}}}{w_{\text{container}}}\right)$$
When rotated to 0° or 180°:
$$\text{scale} = 1$$

Applied to `#video-element`:
`videoEl.style.transform = `rotate(${AppState.videoRotation}deg) scale(${scale})`;`

- `#video-rotate-icon` rotates visually by `AppState.videoRotation` for instant tactile feedback.
- Resize observer / window resize and fullscreen toggle recompute `scale`.
- Loading a new video resets `AppState.videoRotation = 0`.

---

## 4. Verification & QA Protocol

1. **Alphabet Removal Audit**: Verify all target buttons have no visible text and retain `title` / `aria-label`.
2. **Auto-Hide Verification**:
   - Start playback → wait 2.5s → controls fade out.
   - Tap container while hidden → controls reappear without pausing.
   - Tap play button → pause video → controls stay permanently visible.
3. **Rotation Verification**:
   - Tap rotate button 4 times: 0° → 90° → 180° → 270° → 0°.
   - Inspect container bounds: video stays strictly within container at 90°/270° without clipping.
   - Switch video → rotation resets to 0°.
4. **Non-Regression Verification**:
   - Waveform seeker, 5-band equalizer, lyrics modal, playback queue.
   - Photo lightbox zoom/rotate/slideshow.
   - Code editor live iframe preview sandbox and theater modes.
   - IndexedDB export/restore.
